SKK HOMEMADE COOKIES — FREE WEBSITE SETUP

FILES
- index.html: the complete responsive website.

CURRENT SETTINGS
- WhatsApp Business: 60163725055 (Malaysia country code included; digits only).
- Currency: Malaysian Ringgit (RM).
- Products: Pineapple Tarts, Peanut Cookies, German Cookies, Oreo Cookies, Chocolate Almond Cookies.
- Prices and pack sizes are intentionally marked as to be confirmed. They have not been invented.

BEFORE SHARING WITH CUSTOMERS
1. Open index.html in a browser and check the layout on a phone.
2. Confirm the WhatsApp number is correct. Test the order form with a test order; WhatsApp should open with a prepared message. The test message is not sent until you tap Send in WhatsApp.
3. Add the confirmed price and pack size for each product when ready. Until then, the website states that price / pack size is to be confirmed.
4. Confirm delivery/collection area, payment method, lead time and any deposit policy with customers by WhatsApp.

FREE PUBLISHING WITH GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a new public repository, e.g. skk-homemade-cookies.
3. Upload index.html to the repository root (top level, not inside a subfolder).
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select branch main and folder /(root), then Save.
6. Wait a few minutes for the Pages URL shown on that page, usually https://YOUR-USERNAME.github.io/skk-homemade-cookies/.
7. Open the published URL on your phone and test the form again.

IMPORTANT
- GitHub Pages can host a static site free for a public repository, but the URL will be a GitHub Pages address unless you buy/connect a custom domain.
- This is a WhatsApp-order site, not a payment gateway. No online payment is collected on the page.
- Order messages open in WhatsApp and are sent only when the customer taps Send.
- This form does not save orders in a database. Keep the WhatsApp conversation as the order record.
- Prices and pack sizes remain unconfirmed and should be filled in once you decide them.
